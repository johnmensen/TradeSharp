<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

$sharpServerUrl = "70.38.11.49";
$sharpServerPort = 55059;


$client = new SoapClient("http://$sharpServerUrl/AccountEfficiency?wsdl",array('proxy_host' => $sharpServerUrl, 'proxy_port'=> $sharpServerPort, 
  'exceptions'=>true,'trace'=>true, 'encoding'=>'UTF-8'));
$performers = $client->GetAllPerformers();
$stat = $performers->GetAllPerformersResult->PerformerStat;

echo "<html>
<head>
 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
 <style type=\"text/css\">
  table.lightTable { border-width: 0 0 1px 1px; border-spacing: 0; border-collapse: collapse; border-style: solid; }
  table.lightTable tr td { margin: 0; padding: 4px; border-width: 1px 1px 0 0; border-style: solid; }
  tr.rowHeader { background-color: #BBFFAB; font-weight:bold; }
 </style>
</head>
<body>
<h1>GetAllPerformers</h1>
<table class=\"lightTable\">
<tr class=\"rowHeader\">
<td>Account</td>
<td>Login</td>
<td>Group</td>
<td>DepoCurrency</td>
<td>TradeSignal</td>
<td>TradeSignalTitle</td>
<td>SubscriberCount</td>
<td>Score</td>
<td>UserScore</td>
<td>Profit</td>
<td>MaxLeverage</td>
<td>AvgLeverage</td>
<td>MaxRelDrawDown</td>
<td>Sharp</td>
<td>AvgYearProfit</td>
<td>GreedyRatio</td>
<td>ProfitLastMonths</td>
<td>ProfitLastMonthsAbs</td>
<td>WithdrawalLastMonths</td>
<td>TotalTradedInDepoCurrency</td>
<td>AvgWeightedDealProfitToLoss</td>
<td>DealsCount</td>
<td>Equity</td>
</tr>\n";

foreach($stat as $value)
{
	echo "<tr>";
	echo "<td><a href=\"efficiency.php?accountId=$value->Account\">$value->Account</a></td>";
	if(isset($value->Login))
		echo "<td>$value->Login</td>";
	else
		echo "<td/>";
	echo "<td>$value->Group</td>";
	echo "<td>$value->DepoCurrency</td>";
	echo "<td>$value->TradeSignal</td>";
	if(isset($value->TradeSignalTitle))
		echo "<td>$value->TradeSignalTitle</td>";
	else
		echo "<td/>";
	echo "<td>$value->SubscriberCount</td>";
	echo "<td>$value->Score</td>";
	echo "<td>$value->UserScore</td>";
	echo "<td>$value->Profit</td>";
	echo "<td>$value->MaxLeverage</td>";
	echo "<td>$value->AvgLeverage</td>";
	echo "<td>$value->MaxRelDrawDown</td>";
	echo "<td>$value->Sharp</td>";
	echo "<td>$value->AvgYearProfit</td>";
	echo "<td>$value->GreedyRatio</td>";
	echo "<td>$value->ProfitLastMonths</td>";
	echo "<td>$value->ProfitLastMonthsAbs</td>";
	echo "<td>$value->WithdrawalLastMonths</td>";
	echo "<td>$value->TotalTradedInDepoCurrency</td>";
	echo "<td>$value->AvgWeightedDealProfitToLoss</td>";
	echo "<td>$value->DealsCount</td>";
	echo "<td>$value->Equity</td>";
	echo "</tr>\n";
}

//print_r($result);

echo "</table>
</body>
</html>\n";

?>
