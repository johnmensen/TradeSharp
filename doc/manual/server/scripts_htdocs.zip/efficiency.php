<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

if(! isset($_GET['accountId']))
{
	echo "accountId not specified";
	return;
}

echo "<html>
<head>
 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
 <style type=\"text/css\">
   table.lightTable { border-width: 0 0 1px 1px; border-spacing: 0; border-collapse: collapse; border-style: solid; }
   table.lightTable tr td { margin: 0; padding: 4px; border-width: 1px 1px 0 0; border-style: solid; }
   tr.rowHeader { background-color: #BBFFAB; font-weight:bold; }
 </style>
 <script src=\"http://code.jquery.com/jquery-1.10.1.min.js\"></script>
 <script src=\"http://code.jquery.com/jquery-migrate-1.2.1.min.js\"></script>
</head>
<body>
<h1>GetAccountEfficiency(";
echo $_GET['accountId'];
echo ")</h1>\n";

$client = new SoapClient("http://70.38.11.49:55059/AccountEfficiency?wsdl", array('proxy_host' => "70.38.11.49", 'proxy_port'=> 55059, 'exceptions'=>true,'trace'=>true, 'encoding'=>'UTF-8'));
$result = $client->GetAccountEfficiency(array('accountId' => $_GET['accountId']));
if(! isset($result->GetAccountEfficiencyResult))
	return;
$efficiency = $result->GetAccountEfficiencyResult;


echo "<h2 onclick=\"$('#listEquity').toggle()\" style=\"cursor: pointer; color: blue\">listEquity</h2>
<table class=\"lightTable\" id=\"listEquity\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>equity</td>
<td>time</td>
</tr>\n";

$listEquity = $efficiency->listEquity->EquityOnTime;
if(isset($efficiency->listEquity->EquityOnTime)) {
if(! is_array($listEquity))
	$listEquity = array($listEquity);
foreach($listEquity as $value)
{
	echo "<tr>";
	echo "<td>$value->equity</td>";
	echo "<td>$value->time</td>";
	echo "</tr>\n";
}
}

echo "</table>\n";

echo "<h2 onclick=\"$('#listLeverage').toggle()\" style=\"cursor: pointer; color: blue\">listLeverage</h2>
<table class=\"lightTable\" id=\"listLeverage\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>equity</td>
<td>time</td>
</tr>\n";

if(isset($efficiency->listLeverage->EquityOnTime)) {
$listLeverage = $efficiency->listLeverage->EquityOnTime;
if(! is_array($listLeverage))
	$listLeverage = array($listLeverage);
foreach($listLeverage as $value)
{
	echo "<tr>";
	echo "<td>$value->equity</td>";
	echo "<td>$value->time</td>";
	echo "</tr>\n";
}
}

echo "</table>\n";


echo "<h2 onclick=\"$('#listTransaction').toggle()\" style=\"cursor: pointer; color: blue\">listTransaction</h2>
<table class=\"lightTable\" id=\"listTransaction\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>ID</td>
<td>AccountID</td>
<td>ChangeType</td>
<td>Amount</td>
<td>CurrencyToDepoRate</td>
<td>Currency</td>
<td>AmountDepo</td>
<td>ValueDate</td>
<td>Description</td>
<td>SignedAmountDepo</td>
</tr>\n";

if(isset($efficiency->listTransaction->BalanceChange)) {
$listTransaction = $efficiency->listTransaction->BalanceChange;
if(! is_array($listTransaction))
	$listTransaction = array($listTransaction);
foreach($listTransaction as $value)
{
	echo "<tr>";
	echo "<td>$value->ID</td>";
	echo "<td>$value->AccountID</td>";
	echo "<td>$value->ChangeType</td>";
	echo "<td>$value->Amount</td>";
	echo "<td>$value->CurrencyToDepoRate</td>";
	if(isset($value->Currency))
		echo "<td>$value->Currency</td>";
	else
		echo "<td/>";
	if(isset($value->AmountDepo))
		echo "<td>$value->AmountDepo</td>";
	else
		echo "<td/>";
	echo "<td>$value->ValueDate</td>";
	echo "<td>$value->Description</td>";
	if(isset($value->SignedAmountDepo))
		echo "<td>$value->SignedAmountDepo</td>";
	else
		echo "<td/>";
	echo "</tr>\n";
}
}

echo "</table>\n";

echo "<h2 onclick=\"$('#listProfit1000').toggle()\" style=\"cursor: pointer; color: blue\">listProfit1000</h2>
<table class=\"lightTable\" id=\"listProfit1000\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>equity</td>
<td>time</td>
</tr>\n";

if(isset($efficiency->listProfit1000->EquityOnTime)) {
$listProfit1000 = $efficiency->listProfit1000->EquityOnTime;
if(! is_array($listProfit1000))
	$listProfit1000 = array($listProfit1000);
foreach($listProfit1000 as $value)
{
	echo "<tr>";
	echo "<td>$value->equity</td>";
	echo "<td>$value->time</td>";
	echo "</tr>\n";
}
}

echo "</table>\n";

echo "<h2 onclick=\"$('#deals').toggle()\" style=\"cursor: pointer; color: blue\">deals</h2>
<table class=\"lightTable\" id=\"deals\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>ID</td>
<td>AccountID</td>
<td>Volume</td>
<td>Symbol</td>
<td>Side</td>
<td>StopLoss</td>
<td>TakeProfit</td>
<td>PriceEnter</td>
<td>PriceExit</td>
<td>TimeEnter</td>
<td>TimeExit</td>
<td>ResultDepo</td>
<td>ResultBase</td>
<td>ResultPoints</td>
<td>Swap</td>
<td>State</td>
<td>ExitReason</td>
<td>Comment</td>
<td>ExpertComment</td>
<td>Magic</td>
<td>PendingOrderID</td>
<td>PriceBest</td>
<td>PriceWorst</td>
</tr>\n";

if(isset($efficiency->deals->MarketOrder)) {
$deals = $efficiency->deals->MarketOrder;
if(! is_array($deals))
	$deals = array($deals);
foreach($deals as $value)
{
	echo "<tr>";
	echo "<td>$value->ID</td>";
	echo "<td>$value->AccountID</td>";
	echo "<td>$value->Volume</td>";
	echo "<td>$value->Symbol</td>";
	echo "<td>$value->Side</td>";
	echo "<td>$value->StopLoss</td>";
	echo "<td>$value->TakeProfit</td>";
	echo "<td>$value->PriceEnter</td>";
	echo "<td>$value->PriceExit</td>";
	echo "<td>$value->TimeEnter</td>";
	echo "<td>$value->TimeExit</td>";
	echo "<td>$value->ResultDepo</td>";
	echo "<td>$value->ResultBase</td>";
	echo "<td>$value->ResultPoints</td>";
	echo "<td>$value->Swap</td>";
	echo "<td>$value->State</td>";
	echo "<td>$value->ExitReason</td>";
	if(isset($value->Comment))
		echo "<td>$value->Comment</td>";
	else
		echo "<td/>";
	if(isset($value->ExpertComment))
		echo "<td>$value->ExpertComment</td>";
	else
		echo "<td/>";
	echo "<td>$value->Magic</td>";
	echo "<td>$value->PendingOrderID</td>";
	echo "<td>$value->PriceBest</td>";
	echo "<td>$value->PriceWorst</td>";
	echo "</tr>\n";
}
}

echo "</table>\n";

echo "<h2 onclick=\"$('#opendeals').toggle()\" style=\"cursor: pointer; color: blue\">opendeals</h2>
<table class=\"lightTable\" id=\"opendeals\" style=\"display: none\">
<tr class=\"rowHeader\">
<td>ID</td>
<td>AccountID</td>
<td>Volume</td>
<td>Symbol</td>
<td>Side</td>
<td>StopLoss</td>
<td>TakeProfit</td>
<td>PriceEnter</td>
<td>PriceExit</td>
<td>TimeEnter</td>
<td>TimeExit</td>
<td>ResultDepo</td>
<td>ResultBase</td>
<td>ResultPoints</td>
<td>Swap</td>
<td>State</td>
<td>ExitReason</td>
<td>Comment</td>
<td>ExpertComment</td>
<td>Magic</td>
<td>PendingOrderID</td>
<td>PriceBest</td>
<td>PriceWorst</td>
</tr>\n";

if(isset($efficiency->opendeals->MarketOrder)) {
$opendeals = $efficiency->opendeals->MarketOrder;
if(! is_array($opendeals))
	$opendeals = array($opendeals);
foreach($opendeals as $value)
{
	echo "<tr>";
	echo "<td>$value->ID</td>";
	echo "<td>$value->AccountID</td>";
	echo "<td>$value->Volume</td>";
	echo "<td>$value->Symbol</td>";
	echo "<td>$value->Side</td>";
	echo "<td>$value->StopLoss</td>";
	echo "<td>$value->TakeProfit</td>";
	echo "<td>$value->PriceEnter</td>";
	echo "<td>$value->PriceExit</td>";
	echo "<td>$value->TimeEnter</td>";
	echo "<td>$value->TimeExit</td>";
	echo "<td>$value->ResultDepo</td>";
	echo "<td>$value->ResultBase</td>";
	echo "<td>$value->ResultPoints</td>";
	echo "<td>$value->Swap</td>";
	echo "<td>$value->State</td>";
	echo "<td>$value->ExitReason</td>";
	if(isset($value->Comment))
		echo "<td>$value->Comment</td>";
	else
		echo "<td/>";
	if(isset($value->ExpertComment))
		echo "<td>$value->ExpertComment</td>";
	else
		echo "<td/>";
	echo "<td>$value->Magic</td>";
	echo "<td>$value->PendingOrderID</td>";
	echo "<td>$value->PriceBest</td>";
	echo "<td>$value->PriceWorst</td>";
	echo "</tr>\n";
}
}

echo "</table>\n";

echo "</body>
</html>\n";

?>
