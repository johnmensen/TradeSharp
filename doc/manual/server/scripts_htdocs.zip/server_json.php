﻿<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);


        $url = "http://10.5.237.10:8061?register=1&formatquery=1";

        $usrData = array(
               '__type' => 'RegisterAccountQuery:#TradeSharp.Contract.WebContract', 
               'Balance' => 50000, 
               'Currency' => 'USD', 
               'Group' => 'Demo', 
               'MaxLeverage' => 10, 
               'UserDescription' => '', 
               'UserEmail' => 'trytogues@mail.org', 
               'UserLogin' => 'Investor K', 
               'UserName' => 'Investor K', 
               'UserSurname' => 'Investik', 
               'UserPassword' => '12345678', 
               'UserPatronym' => '', 
               'UserPhone1' => '89118058060', 
               'UserPhone2' => '', 
               'UserRightsMask' => 1, 
               'UserRoleMask' => 2);
         
	$arr = array();
        $arr[] = $usrData;
        $content = json_encode($arr);


        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER,
                array("Content-type: application/json"));
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $content);

        $json_response = curl_exec($curl);

        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        //if ( $status != 200 ) {
        //    die("Error: call to URL $url failed with status $status, response $json_response, curl_error " . curl_error($curl) . ", curl_errno " . curl_errno($curl));
        //}

        curl_close($curl);

        $response = json_decode($json_response, true);


echo "<html>
<head>
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
</head>
<body>
   <h3>Response is: </h3>\n <pre>";

   print_r($response);

echo " </pre>\n</body> 
<html>
\n";